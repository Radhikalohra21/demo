#class for db operators
from db_connection import DbConnection

class DbOperations (DbConnection) :
	
	db_status = False

	def __init__(self) :
		super().__init__()
		self.db_status = self.MakeConnection()

		if not(self.db_status) :
			print(self.GetConnError())

	def SelectQuery(self, qry) :
		if self.db_status :
			self.db_cursor.execute(qry)
			return self.db_cursor.fetchall()
		else :
			print(self.GetConnError())
			return False