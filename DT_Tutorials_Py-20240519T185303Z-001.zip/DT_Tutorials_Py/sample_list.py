from db_operations import DbOperations

obj = DbOperations()

qry = "SELECT id, cust_name, cust_code, cust_mobile, cust_email,cust_add1, cust_add2 FROM customer_master WHERE removed != 'Y' ORDER BY cust_code"

res = obj.SelectQuery(qry)

sno = 0

print("")
print("--------------------------------------------------------------")
print("S.No.\tCustomer Code\tMobile No.\tCustomer's Name")
print("--------------------------------------------------------------")

for row in res :
	(cust_id, cust_name, cust_code, cust_mob, cust_email, cust_add1, cust_add2) = row
	#print(cust_id, cust_name, cust_code, cust_mob, cust_email, cust_add1, cust_add2)
	sno = sno + 1
	txt = str(sno)+"\t"+cust_code.strip()+"\t"+cust_mob.strip()+"\t"+cust_name.strip()
	print(txt)

print("--------------------------------------------------------------")	