#class for db connection
import mysql.connector

class DbConnection :

	config = {}
	db_conn = None
	db_cursor = None
	is_error = False
	error_msg = "No Error Set"

	def __init__(self) :
		self.config = {'user': 'root', 'password': 'Qaz123wsx#123Qaz', 'host': '192.168.2.4', 'database' : 'testdb', 'ssl_disabled' : True }
		
	def MakeConnection(self) :
		try :
			self.db_conn = mysql.connector.connect(**self.config)
			self.db_cursor = self.db_conn.cursor()
			self.error_msg = "Db Connected Successfuly !!"
			return True

		except Exception as ex :
			self.SetConnError(ex)
			return False
			
	def SetConnError(self, err_msg) :
		self.is_error = True
		self.error_msg = err_msg
		
		if not(self.db_conn == None) :
			self.db_conn.close()

		if not(self.db_cursor == None) :
			self.db_cursor.close()
			
	def GetConnError(self) : 
		return self.error_msg